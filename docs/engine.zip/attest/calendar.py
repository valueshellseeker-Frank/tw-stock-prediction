from __future__ import annotations
import json
import urllib.parse
import urllib.request
from datetime import date, timedelta
from pathlib import Path
from .common import AttestError, day, iso, read_json, require, timestamp, utcnow, write_json
HOLIDAYS = 'https://www.twse.com.tw/holidaySchedule/holidaySchedule'
OBSERVED = 'https://www.twse.com.tw/exchangeReport/FMTQIK'

def get_json(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'stock-attest/1.0', 'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode('utf-8-sig'))
    except Exception as exc:
        raise AttestError(f'TWSE request failed: {url}; retry later, no calendar fallback') from exc

def planned_sessions(payload, year):
    require(str(payload.get('stat', '')).lower() == 'ok' and payload.get('queryYear') == year, 'TWSE annual schedule unavailable or wrong year')
    require(payload.get('fields', [])[:2] == ['日期', '名稱'] and payload.get('data'), 'TWSE holiday schema changed')
    closed, opened = (set(), set())
    for row in payload['data']:
        require(len(row) >= 3, 'Invalid TWSE holiday row')
        d = day(row[0])
        require(d.year == year, 'TWSE annual schedule contains wrong-year dates')
        name, description = (str(row[1]), str(row[2]))
        if any((token in name for token in ('開始交易日', '最後交易日', '補行交易'))):
            opened.add(d)
        elif any((token in name + description for token in ('放假', '補假', '無交易', '休市'))):
            closed.add(d)
        else:
            raise AttestError(f'Unknown TWSE holiday rule: {d} {name}')
    result = set()
    d = date(year, 1, 1)
    while d.year == year:
        if d.weekday() < 5 and d not in closed or d in opened:
            result.add(d)
        d += timedelta(days=1)
    return sorted(result)

def observed_sessions(payload, year, month):
    status = str(payload.get('stat', ''))
    if not payload.get('data') and any((word in status for word in ('沒有符合', '查無資料'))):
        return []
    require(status.lower() == 'ok' and payload.get('fields', [None])[0] == '日期', 'TWSE actual-session data unavailable or schema changed')
    values = []
    for row in payload.get('data', []):
        try:
            y, m, d = map(int, row[0].split('/'))
            result = date(y + 1911 if y < 1911 else y, m, d)
        except (ValueError, TypeError, IndexError) as exc:
            raise AttestError('Invalid TWSE actual-session date') from exc
        require((result.year, result.month) == (year, month), 'Wrong month in TWSE actual-session response')
        values.append(result)
    require(len(values) == len(set(values)), 'Duplicate TWSE actual sessions')
    return sorted(values)

class TwseCalendar:

    def __init__(self, cache_dir, fetch=get_json, now=None):
        self.cache = Path(cache_dir)
        self.fetch = fetch
        self.now = now or utcnow()

    def _load(self, name, url, ttl_seconds):
        path = self.cache / name
        if path.exists():
            cached = read_json(path)
            age = (self.now - timestamp(cached['fetched_at_utc'])).total_seconds()
            if 0 <= age <= ttl_seconds and cached.get('url') == url:
                return cached
        result = {'url': url, 'fetched_at_utc': iso(self.now), 'payload': self.fetch(url)}
        write_json(path, result)
        return result

    def annual(self, year):
        url = HOLIDAYS + '?' + urllib.parse.urlencode({'response': 'json', 'queryYear': year - 1911})
        evidence = self._load(f'planned-{year}.json', url, 86400)
        return (planned_sessions(evidence['payload'], year), evidence)

    def is_session(self, session):
        d = day(session)
        values, _ = self.annual(d.year)
        return d in values

    def previous_session(self, session):
        d = day(session)
        values, _ = self.annual(d.year)
        before = [v for v in values if v < d]
        if not before:
            before, _ = self.annual(d.year - 1)
        require(before, 'Cannot find previous session in official calendars')
        return before[-1].isoformat()

    def next_session(self, value, inclusive=False):
        d = day(value)
        values, _ = self.annual(d.year)
        after = [v for v in values if v > d or (inclusive and v == d)]
        if not after:
            after, _ = self.annual(d.year + 1)
        require(after, 'Cannot find next session in official calendars')
        return after[0].isoformat()

    def planned_offset(self, session, count):
        d = day(session)
        values, evidence = self.annual(d.year)
        require(d in values, 'session_date is not a planned TWSE trading day')
        future = [value for value in values if value > d]
        sources = [evidence]
        if len(future) < count:
            values, evidence = self.annual(d.year + 1)
            future += values
            sources.append(evidence)
        require(len(future) >= count, 'Published TWSE calendars cannot cover the delay yet')
        return (future[count - 1].isoformat(), sources)

    def observed_between(self, start, end):
        start, end = (day(start), day(end))
        require(start <= end and (end - start).days <= 3700, 'Invalid actual-session query range')
        month = start.replace(day=1)
        values, evidence = ([], [])
        while month <= end:
            url = OBSERVED + '?' + urllib.parse.urlencode({'response': 'json', 'date': month.strftime('%Y%m01')})
            record = self._load(f'actual-{month:%Y-%m}.json', url, 3600)
            values.extend(observed_sessions(record['payload'], month.year, month.month))
            evidence.append(record)
            month = date(month.year + (month.month == 12), month.month % 12 + 1, 1)
        return (sorted((value for value in values if start <= value <= end)), evidence)
