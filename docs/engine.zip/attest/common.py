from __future__ import annotations
import hashlib
import json
import os
import tempfile
from datetime import date, datetime, time, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

class AttestError(Exception):
    """An actionable error that must not include authentication secrets."""

def require(condition, message):
    if not condition:
        raise AttestError(message)

def utcnow():
    return datetime.now(timezone.utc)

def iso(value):
    require(value.tzinfo is not None, 'Timestamp must include timezone')
    return value.astimezone(timezone.utc).isoformat().replace('+00:00', 'Z')

def timestamp(value):
    try:
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except (ValueError, TypeError, AttributeError) as exc:
        raise AttestError('Invalid ISO-8601 timestamp') from exc
    require(result.tzinfo is not None, 'Timestamp must include Z or UTC offset')
    return result.astimezone(timezone.utc)

def day(value):
    try:
        result = date.fromisoformat(value)
    except (TypeError, ValueError) as exc:
        raise AttestError('Date must be YYYY-MM-DD') from exc
    require(result.isoformat() == value, 'Date must be canonical YYYY-MM-DD')
    return result

def clock_time(value):
    try:
        result = time.fromisoformat(value)
    except (TypeError, ValueError) as exc:
        raise AttestError('Time must be HH:MM:SS') from exc
    require(result.tzinfo is None, 'Use the configured timezone, not a time offset')
    return result

def at(session, value, tz):
    return datetime.combine(day(session), clock_time(value), ZoneInfo(tz))

def canonical(obj):
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def write_bytes(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.write-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)

def write_json(path, obj):
    write_bytes(path, canonical(obj))
