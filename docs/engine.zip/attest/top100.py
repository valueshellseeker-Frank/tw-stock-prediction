from __future__ import annotations
import csv
import io
import re
from datetime import timedelta
from .common import at, day, require

def direct_public(protocol, session):
    policy = protocol.get('publication_policy', {})
    mode = policy.get('mode', 'delayed')
    require(mode in ('delayed', 'weekly_weekend', 'biweekly_weekend'), 'Unknown fixed disclosure policy')
    if mode == 'delayed':
        return False
    d = day(session)
    if d.weekday() != 0:
        return False
    anchor = day(policy['anchor_monday'])
    require(anchor.weekday() == 0, 'Public disclosure anchor must be a Monday')
    weeks = (d - anchor).days // 7
    return weeks >= 0 and weeks % (2 if mode == 'biweekly_weekend' else 1) == 0

def direct_not_before(protocol, session):
    require(direct_public(protocol, session), 'Session is not a direct-public slot')
    sunday = (day(session) - timedelta(days=1)).isoformat()
    return at(sunday, protocol['publication_policy']['weekend_public_time'], protocol['timezone'])

def window_start(cfg, session, calendar):
    previous = calendar.previous_session(session)
    start = at(previous, cfg['publication_policy']['previous_session_window_start'], cfg['timezone'])
    if direct_public(cfg, session):
        start = max(start, direct_not_before(cfg, session))
    return start

def validate_membership(raw):
    require(len(raw) <= 32 * 1024, 'Top100 CSV exceeds size limit')
    reader = csv.DictReader(io.StringIO(raw.decode('utf-8-sig'), newline=''))
    require(reader.fieldnames == ['stock_id'], 'Top100 CSV must contain exactly one column: stock_id')
    rows = list(reader)
    require(len(rows) == 100 and all((None not in row for row in rows)), 'Top100 CSV requires exactly 100 rows and the declared columns')
    ids = [r['stock_id'] for r in rows]
    require(all((isinstance(v, str) and re.fullmatch('[A-Za-z0-9]{1,12}', v) for v in ids)), 'Invalid stock_id; preserve leading zeros as text')
    require(len(set(ids)) == 100, 'Top100 has duplicate stock IDs')
    require(ids == sorted(ids), 'Stock IDs must be in ascending text order')
    return ids
