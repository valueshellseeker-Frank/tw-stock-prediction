from __future__ import annotations
import base64
import math
import re
import zlib
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from ..common import AttestError, canonical, require
CHAIN_HASH = '52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971'
GENESIS = 1692803367
PERIOD = 3
MAX_CAPSULE_BYTES = 107520

def unb64(value):
    try:
        return base64.b64decode(value, validate=True)
    except (ValueError, TypeError) as exc:
        raise AttestError('Invalid base64 field') from exc

def unpack_optional_gzip(raw, maximum):
    """Accept historical raw bytes or a single, bounded gzip member."""
    if not raw.startswith(b'\x1f\x8b'):
        require(len(raw) <= maximum, 'Object exceeds size limit')
        return raw
    decoder = zlib.decompressobj(wbits=31)
    try:
        result = decoder.decompress(raw, maximum + 1)
    except zlib.error as exc:
        raise AttestError('Invalid gzip object') from exc
    require(len(result) <= maximum, 'Decompressed object exceeds size limit')
    require(decoder.eof and (not decoder.unused_data), 'Incomplete gzip object or trailing data')
    return result

def round_for_time(value):
    """Round 1 is at genesis; ceil ensures never earlier than the declared time."""
    return max(1, math.ceil((value.timestamp() - GENESIS) / PERIOD) + 1)

def validate_header(ciphertext, number):
    """Reject extra recipients, passwords, wrong round or a substituted drand chain."""
    try:
        text = ciphertext.decode('ascii').strip()
        lines = text.splitlines()
        require(lines[0] == '-----BEGIN AGE ENCRYPTED FILE-----' and lines[-1] == '-----END AGE ENCRYPTED FILE-----', 'Expected official armored age/tlock format')
        raw = base64.b64decode(''.join(lines[1:-1]), validate=True)
        header = raw.split(b'\n--- ', 1)[0].decode('ascii')
    except (ValueError, UnicodeError, IndexError) as exc:
        raise AttestError('Invalid age/tlock ciphertext header') from exc
    require(header.startswith('age-encryption.org/v1\n'), 'Unsupported age version')
    recipients = re.findall('^-> (.+)$', header, re.M)
    require(recipients == [f'tlock {number} {CHAIN_HASH}'], 'Only the declared quicknet tlock recipient is allowed; no owner-only password')

def verify_signature(obj, expected_public):
    require(isinstance(obj, dict) and 'signature_ed25519' in obj, 'Missing capsule signature')
    unsigned = {k: v for k, v in obj.items() if k != 'signature_ed25519'}
    try:
        Ed25519PublicKey.from_public_bytes(unb64(expected_public)).verify(unb64(obj['signature_ed25519']), canonical(unsigned))
    except Exception as exc:
        raise AttestError('Capsule signature does not match the pinned publisher key') from exc
    return unsigned
