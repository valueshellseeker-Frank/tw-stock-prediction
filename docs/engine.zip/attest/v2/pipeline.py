from __future__ import annotations
import json
from ..common import AttestError, canonical, require, sha
from .crypto import MAX_CAPSULE_BYTES, unb64, validate_header, verify_signature
from .policy import protocol_hash, release_plan, slot_cid, slot_name, validate_protocol
from .public_format import validate_payload
CAPSULE_SCHEMA = 'stock-attest/capsule/v2'

def validate_capsule(raw, protocol):
    validate_protocol(protocol)
    require(len(raw) <= MAX_CAPSULE_BYTES, 'Capsule exceeds size limit')
    try:
        obj = json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeError) as exc:
        raise AttestError('Invalid capsule JSON') from exc
    require(canonical(obj) == raw, 'Capsule must use canonical JSON; duplicate/noncanonical keys are forbidden')
    fields = {'schema', 'protocol_sha256', 'strategy_id', 'session_date', 'slot_name', 'slot_cid', 'disclosure', 'previous_local_revision', 'body_sha256', 'body_base64', 'signature_ed25519'}
    require(set(obj) == fields and obj['schema'] == CAPSULE_SCHEMA, 'Unknown capsule fields/schema')
    verify_signature(obj, protocol['signing_public_key_ed25519'])
    require(obj['protocol_sha256'] == protocol_hash(protocol) and obj['strategy_id'] == protocol['strategy_id'], 'Protocol/series identity mismatch')
    session = obj['session_date']
    require(obj['slot_name'] == slot_name(protocol, session) and obj['slot_cid'] == slot_cid(protocol, session), 'Unexpected deterministic daily collection')
    require(obj['disclosure'] == release_plan(protocol, session), 'Round/reveal mode differs from the fixed public protocol')
    body = unb64(obj['body_base64'])
    require(sha(body) == obj['body_sha256'], 'Ciphertext fingerprint mismatch')
    if obj['disclosure']['mode'] == 'delayed':
        validate_header(body, obj['disclosure']['round'])
    else:
        validate_payload(body, protocol, session)
    return obj
