from __future__ import annotations
import hashlib
from datetime import timedelta
from ..common import at, canonical, day, iso, require, sha
from ..top100 import direct_not_before, direct_public, window_start
from .crypto import CHAIN_HASH, round_for_time
from .public_format import validate_protocol
CUTOFF_TAIPEI = '08:30:00'
MARKET_OPEN_TAIPEI = '09:00:00'

def cid(raw):
    return '0x' + hashlib.sha3_256(raw).hexdigest()

def protocol_hash(protocol):
    validate_protocol(protocol)
    return sha(canonical(protocol))

def slot_name(protocol, session):
    day(session)
    return f'ml-v2-{protocol_hash(protocol)}-{session}'

def slot_cid(protocol, session):
    return cid(slot_name(protocol, session).encode('utf-8'))

def release_plan(protocol, session):
    public = direct_public(protocol, session)
    if public:
        unlock = direct_not_before(protocol, session)
    else:
        disclosure = protocol['disclosure']
        reveal_date = day(session) + timedelta(days=disclosure['calendar_days'])
        unlock = at(reveal_date.isoformat(), disclosure['time_taipei'], 'Asia/Taipei')
    return {'mode': 'public' if public else 'delayed', 'unlock_at_utc': iso(unlock), 'round': None if public else round_for_time(unlock), 'chain_hash': CHAIN_HASH}

def cutoff(session, protocol=None):
    time = CUTOFF_TAIPEI if protocol is None else protocol['registration']['cutoff_taipei']
    return at(session, time, 'Asia/Taipei')

def announcement_deadline(protocol, calendar):
    """New series use the first 08:30 cutoff; retain older signed rules verbatim."""
    rule = protocol['public_evidence']['announcement_before']
    if rule == 'first_session_cutoff':
        return cutoff(protocol['start_date'], protocol)
    require(rule == 'first_publication_window', 'Unsupported announcement deadline')
    return window_start(protocol, protocol['start_date'], calendar)
