from __future__ import annotations
import json
import re
from ..common import AttestError, canonical, day, require, sha
from ..top100 import validate_membership
from .crypto import CHAIN_HASH
PRIVACY_FORMAT = 'evidence-only/v1'
PROTOCOL_FIELDS = {'schema', 'privacy_format', 'strategy_id', 'author', 'signing_public_key_ed25519', 'start_date', 'timezone', 'calendar', 'artifact_kind', 'top_k', 'registration', 'disclosure', 'publication_policy', 'public_evidence', 'completeness'}

def validate_protocol(p):
    require(isinstance(p, dict) and set(p) == PROTOCOL_FIELDS, 'Unexpected public protocol fields')
    require(p['schema'] == 'stock-attest/protocol/v2' and p['privacy_format'] == PRIVACY_FORMAT, 'Unsupported public evidence format')
    require(p['top_k'] == 100 and p['artifact_kind'] == 'top100_membership_v1', 'Unsupported list format')
    require(p['timezone'] == 'Asia/Taipei' and p['calendar'] == 'TWSE', 'Unsupported market')
    require(re.fullmatch('[A-Za-z0-9][A-Za-z0-9._-]{0,63}', p['strategy_id']), 'Invalid series ID')
    if p['start_date'] is not None:
        day(p['start_date'])
    r = p['registration']
    require(set(r) == {'producer_address', 'chain_id', 'contract_address', 'deployment_block', 'finality_tag', 'official_revision', 'cutoff_taipei', 'comparison', 'ordering', 'invalid_last'}, 'Unexpected registration fields')
    require(r['official_revision'] == 'last_registered_before_cutoff' and r['cutoff_taipei'] == '08:30:00' and (r['comparison'] == 'strictly_less_than') and (r['invalid_last'] == 'invalid_period_no_fallback') and (r['ordering'] == ['block_number', 'transaction_index', 'log_index']), 'Official selection rule mismatch')
    for key in ('producer_address', 'contract_address'):
        require(r[key] is None or re.fullmatch('0x[0-9a-fA-F]{40}', r[key]), 'Invalid registry address')
    for key in ('chain_id', 'deployment_block'):
        require(r[key] is None or (type(r[key]) is int and r[key] >= (1 if key == 'chain_id' else 0)), 'Invalid registry integer')
    require(r['finality_tag'] in (None, 'finalized'), 'Unexpected finality policy')
    require(p['disclosure'] == {'calendar_days': 30, 'time_taipei': '18:00:00', 'chain_hash': CHAIN_HASH, 'requires_owner_secret': False}, 'Disclosure rule mismatch')
    policy = p['publication_policy']
    require(set(policy) == {'mode', 'anchor_monday', 'weekend_public_time', 'previous_session_window_start', 'holiday_policy'}, 'Unexpected disclosure schedule fields')
    require(policy['mode'] in ('delayed', 'biweekly_weekend') and day(policy['anchor_monday']).weekday() == 0 and (policy['weekend_public_time'] in ('18:00:00', '22:00:00')) and (policy['previous_session_window_start'] == '16:00:00') and (policy['holiday_policy'] == 'skip_week'), 'Invalid disclosure schedule')
    evidence = p['public_evidence']
    require(isinstance(evidence, dict) and re.fullmatch('[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', evidence.get('github_repo', '')), 'Invalid public repo binding')
    require(evidence.get('announcement_before') in ('first_publication_window', 'first_session_cutoff'), 'Unsupported announcement deadline')
    require(evidence == {'github_repo': evidence['github_repo'], 'anchor_tag': 'series-policy-v2', 'announcement_before': evidence['announcement_before'], 'capsule_publication_before': 'session_cutoff', 'backup': 'public_arweave_capsule', 'whole_series_inventory': True}, 'Public evidence policy mismatch')
    return p

def validate_payload(raw, protocol, session):
    validate_protocol(protocol)
    require(len(raw) <= 64 * 1024, 'Decrypted payload exceeds size limit')
    try:
        p = json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeError) as exc:
        raise AttestError('Invalid decrypted payload') from exc
    require(canonical(p) == raw and set(p) == {'schema', 'protocol_sha256', 'session_date', 'top100_csv', 'random_salt_hex'}, 'Unexpected decrypted payload fields')
    require(p['schema'] == 'stock-attest/payload/v2' and p['protocol_sha256'] == sha(canonical(protocol)) and (p['session_date'] == session), 'Decrypted payload belongs to another protocol/session')
    require(isinstance(p['random_salt_hex'], str) and re.fullmatch('[0-9a-f]{64}', p['random_salt_hex']), 'Missing payload privacy salt')
    raw_csv = p['top100_csv'].encode('utf-8')
    validate_membership(raw_csv)
    return (raw_csv, {})
