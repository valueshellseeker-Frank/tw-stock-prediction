from __future__ import annotations
import json
import re
from pathlib import Path
from ..common import at, day, iso, require, timestamp
from .policy import MARKET_OPEN_TAIPEI, cutoff, protocol_hash, slot_cid
from .services import get_bytes
from .crypto import MAX_CAPSULE_BYTES

def load_public_protocol(source, expected_hash):
    require(re.fullmatch('[0-9a-f]{64}', expected_hash), 'Supply the preannounced 64-character lowercase protocol SHA-256')
    if source.startswith('https://'):
        raw, _ = get_bytes(source)
    else:
        path = Path(source)
        require(path.stat().st_size <= MAX_CAPSULE_BYTES, 'Public protocol file exceeds the size limit')
        raw = path.read_bytes()
    protocol = json.loads(raw.decode('utf-8-sig'))
    require(protocol_hash(protocol) == expected_hash, 'Protocol differs from the independently pinned series; stop before any registry query')
    identity = protocol['registration']
    require(protocol['start_date'] is not None, 'A local draft without a public start_date cannot be verified as a formal series')
    day(protocol['start_date'])
    require(all((identity.get(k) is not None for k in ('producer_address', 'chain_id', 'contract_address', 'deployment_block', 'finality_tag'))), 'Public registry identity/finality is incomplete')
    require(identity['finality_tag'] == 'finalized', 'Public verifier requires the finalized block policy')
    return protocol

def registration_claims(row, protocol):
    """Shared registration verdict for the browser and CLI."""
    event = row.get('candidate')
    external = row['third_party_registration_verified']
    deadline = cutoff(row['session_date'], protocol)
    unique = 'pass' if external and event else 'fail' if external else 'pending'
    premarket = 'pass' if external and event and (timestamp(event['block_time_utc']) < deadline) else 'fail' if external else 'pending'
    return {'unique_official_revision': {'status': unique, 'meaning': 'one official result at the predeclared registry location; all eligible revisions visible; last before open wins', 'complete_history_scope': 'all registrations in the declared premarket publication window', 'collection_cid': slot_cid(protocol, row['session_date']), 'fixed_location_history_complete_before_cutoff': external, 'registered_revisions_before_cutoff': row['revisions_before_cutoff'], 'official_revision_count': 1 if unique == 'pass' else 0 if external else None, 'official_cid': event['object_cid'] if event and unique == 'pass' else None, 'candidate_cid': event['object_cid'] if event else None, 'superseded_revisions': len(row['superseded']), 'late_revisions': len(row['late'])}, 'premarket_public_commitment': {'status': premarket, 'registered_at_utc': event['block_time_utc'] if event else None, 'cutoff_utc': iso(deadline), 'market_open_utc': iso(at(row['session_date'], MARKET_OPEN_TAIPEI, protocol['timezone'])), 'what_was_public': 'vBase on-chain CID commitment, not early plaintext disclosure'}}
