from ..common import iso, require, sha, timestamp

def check_public_asset(release, name, raw, before, repo):
    require(release.get('draft') is False and release.get('immutable') is True, 'Release is not published and immutable')
    require(timestamp(release['published_at']) < before, 'Public release was not published strictly before the required deadline')
    assets = [a for a in release.get('assets', []) if a.get('name') == name]
    require(len(assets) == 1, 'Expected exactly one public asset')
    asset = assets[0]
    require(asset.get('state') == 'uploaded' and asset.get('size') == len(raw) and (asset.get('digest') == 'sha256:' + sha(raw)), 'GitHub asset bytes/digest differ from the committed file')
    require(timestamp(asset['created_at']) <= timestamp(release['published_at']), 'Asset creation is later than release publication')
    return {'status': 'pass', 'repo': repo, 'tag': release['tag_name'], 'release_id': release['id'], 'published_at_utc': iso(timestamp(release['published_at'])), 'required_before_utc': iso(before), 'asset_id': asset['id'], 'asset_sha256': sha(raw), 'evidence_basis': 'public GitHub HTTPS API: immutable, published_at and asset digest', 'attestation_signature_verified_locally': False, 'historical_anonymous_download_verified': False}
