from __future__ import annotations
import json
import re
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from ..common import AttestError, canonical, iso, require, timestamp
from .policy import cutoff, slot_cid
EVENT_TOPIC = '0x38caddea36d4bb0fc2e9597e46fd18beb7d9b9508b4a997e438bdb877a17efa4'

def number(value):
    require(isinstance(value, (str, int)) and (not isinstance(value, bool)), 'Invalid RPC integer')
    return int(value, 16) if isinstance(value, str) else value

def address_topic(value):
    require(isinstance(value, str) and re.fullmatch('0x[0-9a-fA-F]{40}', value), 'Configure the pinned EVM producer address')
    return '0x' + value[2:].lower().zfill(64)

class JsonRpc:
    READ_METHODS = {'eth_chainId', 'eth_getBlockByNumber', 'eth_getLogs', 'eth_getTransactionReceipt', 'eth_call'}

    def __init__(self, url):
        require(url.startswith('https://'), 'RPC must use HTTPS')
        self.url = url

    def call(self, method, params):
        require(method in self.READ_METHODS, 'This RPC client permits read-only methods')
        req = urllib.request.Request(self.url, data=canonical({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}), headers={'Content-Type': 'application/json', 'User-Agent': 'stock-attest/2.0'})
        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                obj = json.loads(response.read(16 * 1024 * 1024))
            require('error' not in obj and 'result' in obj, 'RPC returned an error; refusing partial evidence')
            return obj['result']
        except (OSError, ValueError) as exc:
            raise AttestError('Read-only RPC failed; URL/credentials are not logged') from exc

@dataclass(frozen=True)
class Snapshot:
    events: tuple
    trust: str
    complete_before_cutoff: bool
    evidence: dict

def imported_snapshot(data):
    return Snapshot(tuple(data.get('events', [])), 'local_fixture_unverified', False, {'warning': 'Imported JSON cannot independently prove publication time or completeness'})

def ordering(event):
    result = tuple((event[k] for k in ('block_number', 'transaction_index', 'log_index')))
    require(all((type(x) is int and x >= 0 for x in result)), 'Registry ordering needs nonnegative chain integers')
    return result

def choose(snapshot, protocol, session, window_start):
    eligible, early, late = ([], [], [])
    seen = {}
    identity = protocol['registration']
    expected_slot = slot_cid(protocol, session)
    deadline = cutoff(session, protocol)
    for event in snapshot.events:
        require(event['producer_address'].lower() == str(identity['producer_address']).lower(), 'Registry producer differs from public protocol')
        require(event['contract_address'].lower() == str(identity['contract_address']).lower() and event['chain_id'] == identity['chain_id'], 'Registry chain/contract differs from protocol')
        require(event['slot_cid'] == expected_slot, 'Registry event is not from this deterministic daily collection')
        require(re.fullmatch('0x[0-9a-f]{64}', event['object_cid']), 'Invalid vBase object CID')
        key = ordering(event)
        if key in seen:
            require(seen[key] == event, 'Conflicting events at the same canonical log position')
            continue
        seen[key] = event
        t = timestamp(event['block_time_utc'])
        target = early if t < window_start else late if t >= deadline else eligible
        target.append(event)
    eligible.sort(key=ordering)
    official = eligible[-1] if eligible else None
    return {'session_date': session, 'candidate': official, 'revisions_before_cutoff': len(eligible), 'superseded': eligible[:-1], 'too_early': sorted(early, key=ordering), 'late': sorted(late, key=ordering), 'evidence_trust': snapshot.trust, 'third_party_registration_verified': snapshot.trust == 'rpc_canonical_finalized' and snapshot.complete_before_cutoff, 'status': 'missing' if official is None else 'selected' if snapshot.complete_before_cutoff else 'provisional_unverified', 'evidence': snapshot.evidence}

class RegistryReader:

    def __init__(self, rpc, *, event_topic=None, log_chunk_size=10000):
        require(type(log_chunk_size) is int and 1 <= log_chunk_size <= 10000, 'Invalid RPC log chunk size')
        self.rpc = rpc
        self.event_topic = event_topic
        self.log_chunk_size = log_chunk_size

    def scan(self, protocol, session, start):
        identity = protocol['registration']
        require(all((identity.get(k) is not None for k in ('producer_address', 'chain_id', 'contract_address', 'deployment_block', 'finality_tag'))), 'Registry identity/finality is not configured')
        require(identity['finality_tag'] == 'finalized', 'v2 requires the finalized block tag; no latest-head fallback')
        require(number(self.rpc.call('eth_chainId', [])) == identity['chain_id'], 'RPC chain ID mismatch')
        require(re.fullmatch('0x[0-9a-fA-F]{40}', identity['contract_address']), 'Invalid pinned contract')
        head = self.rpc.call('eth_getBlockByNumber', ['finalized', False])
        require(head, 'RPC has no finalized block; cannot prove completeness')
        head_number = number(head['number'])
        cache = {head_number: head}

        def block(n):
            if n not in cache:
                cache[n] = self.rpc.call('eth_getBlockByNumber', [hex(n), False])
            require(cache[n] and number(cache[n]['number']) == n, 'Missing/wrong canonical block header')
            return cache[n]

        def lower_bound(instant):
            lo, hi = (identity['deployment_block'], head_number + 1)
            while lo < hi:
                mid = (lo + hi) // 2
                if number(block(mid)['timestamp']) < int(instant.timestamp()):
                    lo = mid + 1
                else:
                    hi = mid
            return lo
        topic = self.event_topic or EVENT_TOPIC
        begin = lower_bound(start)
        deadline = cutoff(session, protocol)
        end = min(head_number, lower_bound(deadline + timedelta(days=1)) - 1)
        logs = []
        for first in range(begin, end + 1, self.log_chunk_size):
            chunk = self.rpc.call('eth_getLogs', [{'address': identity['contract_address'], 'topics': [topic, address_topic(identity['producer_address']), slot_cid(protocol, session)], 'fromBlock': hex(first), 'toBlock': hex(min(end, first + self.log_chunk_size - 1))}])
            require(isinstance(chunk, list), 'RPC returned a non-list log result')
            logs.extend(chunk)
        events = []
        for log in logs:
            topics = log.get('topics', [])
            require(log.get('removed') is not True and len(topics) == 4, 'Removed/malformed event')
            require(log['address'].lower() == identity['contract_address'].lower() and topics[:3] == [topic, address_topic(identity['producer_address']), slot_cid(protocol, session)], 'RPC log filter mismatch')
            n = number(log['blockNumber'])
            require(begin <= n <= end, 'RPC returned log outside requested range')
            header = block(n)
            require(log['blockHash'].lower() == header['hash'].lower(), 'Registry log is not in the canonical block')
            receipt = self.rpc.call('eth_getTransactionReceipt', [log['transactionHash']])
            require(receipt and number(receipt['status']) == 1 and (receipt['blockHash'].lower() == header['hash'].lower()), 'Registry transaction failed or reorged')
            matches = [x for x in receipt['logs'] if number(x['logIndex']) == number(log['logIndex'])]
            require(len(matches) == 1 and all((matches[0].get(k) == log.get(k) for k in ('address', 'topics', 'data', 'transactionHash', 'blockHash'))), 'Log does not match its canonical transaction receipt')
            require(number(receipt['transactionIndex']) == number(log['transactionIndex']), 'Transaction index mismatch')
            events.append({'producer_address': identity['producer_address'], 'contract_address': identity['contract_address'], 'chain_id': identity['chain_id'], 'slot_cid': topics[2], 'object_cid': topics[3], 'block_number': n, 'transaction_index': number(log['transactionIndex']), 'log_index': number(log['logIndex']), 'transaction_hash': log['transactionHash'], 'block_hash': header['hash'], 'block_time_utc': iso(datetime.fromtimestamp(number(header['timestamp']), timezone.utc))})
        again = self.rpc.call('eth_getBlockByNumber', [hex(head_number), False])
        require(again['hash'] == head['hash'], 'Finalized snapshot changed while scanning; discard and retry')
        complete = number(head['timestamp']) >= int(deadline.timestamp())
        return Snapshot(tuple(events), 'rpc_canonical_finalized', complete, {'finalized_block': head_number, 'finalized_block_hash': head['hash'], 'scan_from_block': begin, 'scan_to_block': end, 'time_basis': 'canonical block header, not vBase receipt/event timestamp', 'trust_basis': 'configured HTTPS RPC; offline JSON is never promoted to this trust level'})

def compare_snapshots(snapshots, session, *, protocol=None):
    """Cross-check every configured RPC on all events before the market cutoff."""
    require(snapshots, 'No registry snapshot')
    deadline = cutoff(session, protocol)

    def prior(snapshot):
        return sorted((e for e in snapshot.events if timestamp(e['block_time_utc']) < deadline), key=ordering)
    expected = prior(snapshots[0])
    require(all((prior(s) == expected for s in snapshots[1:])), 'Configured RPCs disagree on premarket history; no official-version claim')
    complete = all((s.complete_before_cutoff and s.trust == 'rpc_canonical_finalized' for s in snapshots))
    return Snapshot(snapshots[0].events, 'rpc_canonical_finalized', complete, {'rpc_count': len(snapshots), 'snapshots': [s.evidence for s in snapshots], 'cross_check': 'all configured RPCs must agree on the complete pre-cutoff event list'})
