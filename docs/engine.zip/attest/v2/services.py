from __future__ import annotations
import json
import re
import urllib.error
import urllib.parse
import urllib.request
from ..common import AttestError, canonical, require, sha
from .crypto import MAX_CAPSULE_BYTES, unpack_optional_gzip
from .policy import cid

def get_bytes(url, maximum=MAX_CAPSULE_BYTES):
    require(url.startswith('https://'), 'Public reads require HTTPS')
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'stock-attest/2.0'})
        with urllib.request.urlopen(req, timeout=30) as response:
            raw = response.read(maximum + 1)
            headers = dict(response.headers.items())
        require(len(raw) <= maximum, 'Public object exceeds size limit')
        return (raw, {k.lower(): v for k, v in headers.items()})
    except OSError as exc:
        raise AttestError('Public archive read failed; no credentialed fallback') from exc

class ArchiveReader:

    def __init__(self, *, query_json=None, fetch_bytes=None):
        self.query_json = query_json
        self.fetch_bytes = fetch_bytes

    def fetch(self, object_id, expected_cid, gateway='https://turbo-gateway.com'):
        require(re.fullmatch('[A-Za-z0-9_-]{43}', object_id), 'Invalid Arweave data item ID')
        require(gateway in ('https://turbo-gateway.com', 'https://arweave.net'), 'Unexpected public archive gateway')
        stored, headers = (self.fetch_bytes or get_bytes)(gateway + '/raw/' + object_id)
        require(len(stored) <= MAX_CAPSULE_BYTES, 'Public object exceeds size limit')
        raw = unpack_optional_gzip(stored, MAX_CAPSULE_BYTES)
        require(cid(raw) == expected_cid, 'Archive bytes do not match the official registry CID')
        return (raw, {'object_id': object_id, 'sha256': sha(raw), 'vbase_cid': cid(raw), 'archive_bytes': len(stored), 'gateway_reports_verified': headers.get('x-ar-io-verified') == 'true', 'gateway_reports_stable': headers.get('x-ar-io-stable') == 'true', 'cryptographic_inclusion_proof_verified': False})

    def discover(self, expected_cid):
        require(re.fullmatch('0x[0-9a-f]{64}', expected_cid), 'Invalid lookup CID')
        query = 'query($cid:String!){transactions(first:100,tags:[{name:"App-Name",values:["ML-Stock-Attest-v2"]},{name:"VBase-CID",values:[$cid]}]){edges{node{id}}}}'
        body = canonical({'query': query, 'variables': {'cid': expected_cid}})
        successful = False
        for url in ('https://turbo-gateway.com/graphql', 'https://arweave.net/graphql'):
            try:
                if self.query_json is None:
                    req = urllib.request.Request(url, data=body, headers={'Content-Type': 'application/json', 'User-Agent': 'stock-attest/2.0'})
                    with urllib.request.urlopen(req, timeout=30) as response:
                        result = json.loads(response.read(1024 * 1024))
                else:
                    result = self.query_json(url, body)
                edges = result['data']['transactions']['edges']
            except (AttestError, OSError, ValueError, KeyError, TypeError):
                continue
            require(len(edges) < 100, 'Archive lookup exceeds bounded result count; use the recorded Arweave ID')
            successful = True
            if edges:
                return list(dict.fromkeys((x['node']['id'] for x in edges)))
        require(successful, 'Public archive discovery failed; no partial-success claim')
        return []

    def resolve(self, expected_cid, *, gateways=('https://turbo-gateway.com',)):
        ids = self.discover(expected_cid)
        for object_id in ids:
            for gateway in gateways:
                try:
                    return self.fetch(object_id, expected_cid, gateway=gateway)
                except AttestError:
                    continue
        raise AttestError('Official CID has no retrievable matching archive object')
