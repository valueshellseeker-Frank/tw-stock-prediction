import base64
import hashlib
import json
import re
from datetime import datetime, timezone
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa, utils
from ..common import iso, require, sha
from .crypto import MAX_CAPSULE_BYTES, unpack_optional_gzip
from .services import get_bytes
TURBO_SIGNERS = ('JNC6vBhjHY1EPwV3pEeNmrsgFMxH5d38_LHsZ7jful8',)
TURBO = 'https://upload.ardrive.io'
ARWEAVE = 'https://arweave.net'
RECEIPT_FIELDS = ('version', 'id', 'deadlineHeight', 'timestamp', 'public', 'signature')

def decode(value):
    require(isinstance(value, str) and re.fullmatch('[A-Za-z0-9_-]*', value) is not None, 'Invalid base64url')
    return base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))

def encode(value):
    return base64.urlsafe_b64encode(value).decode('ascii').rstrip('=')

def deep_hash(value):
    h = lambda x: hashlib.sha384(x).digest()
    if isinstance(value, list):
        result = h(b'list' + str(len(value)).encode())
        for part in value:
            result = h(result + deep_hash(part))
        return result
    return h(h(b'blob' + str(len(value)).encode()) + h(value))

def rsa_verify(owner, signature, message, salt=padding.PSS.AUTO):
    require(len(owner) == 512 and len(signature) == 512, 'Expected 4096-bit Arweave RSA key')
    key = rsa.RSAPublicNumbers(65537, int.from_bytes(owner, 'big')).public_key()
    key.verify(signature, message, padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=salt), hashes.SHA256())

def receipt_fields(receipt):
    return {name: receipt[name] for name in RECEIPT_FIELDS}

def verify_receipt(receipt, item_id, before):
    require(receipt['version'] == '0.2.0' and receipt['id'] == item_id, 'Receipt version or item ID differs')
    require(re.fullmatch('[A-Za-z0-9_-]{43}', item_id), 'Invalid receipt ID')
    for field in ('timestamp', 'deadlineHeight'):
        require(type(receipt[field]) is int and receipt[field] > 0, 'Invalid signed receipt number')
    signer = encode(hashlib.sha256(decode(receipt['public'])).digest())
    require(signer in TURBO_SIGNERS, 'Receipt is not signed by the pinned Turbo service')
    message = deep_hash([str(v).encode('utf-8') for v in ('Bundlr', receipt['version'], item_id, receipt['deadlineHeight'], receipt['timestamp'])])
    rsa_verify(decode(receipt['public']), decode(receipt['signature']), message, salt=0)
    accepted = datetime.fromtimestamp(receipt['timestamp'] / 1000, timezone.utc)
    return {'status': 'pass' if accepted < before else 'fail', 'signature_valid': True, 'item_id': item_id, 'signer': signer, 'accepted_at_utc': iso(accepted), 'strictly_before_cutoff': accepted < before, 'required_before_utc': iso(before), 'deadline_height': receipt['deadlineHeight'], 'historical_anonymous_download_verified': False}

def keccak256(data):
    """Keccak-256 for EIP-191 (not NIST SHA3-256); no runtime dependency."""
    rotations = (0, 1, 62, 28, 27, 36, 44, 6, 55, 20, 3, 10, 43, 25, 39, 41, 45, 15, 21, 8, 18, 2, 61, 56, 14)
    constants = (1, 32898, 9223372036854808714, 9223372039002292224, 32907, 2147483649, 9223372039002292353, 9223372036854808585, 138, 136, 2147516425, 2147483658, 2147516555, 9223372036854775947, 9223372036854808713, 9223372036854808579, 9223372036854808578, 9223372036854775936, 32778, 9223372039002259466, 9223372039002292353, 9223372036854808704, 2147483649, 9223372039002292232)
    mask = (1 << 64) - 1
    rotate = lambda x, n: (x << n | x >> 64 - n) & mask
    padded = bytearray(data)
    padded.append(1)
    padded.extend(b'\x00' * (-len(padded) % 136))
    padded[-1] |= 128
    state = [0] * 25
    for start in range(0, len(padded), 136):
        for i in range(17):
            state[i] ^= int.from_bytes(padded[start + 8 * i:start + 8 * i + 8], 'little')
        for rc in constants:
            columns = [state[x] ^ state[x + 5] ^ state[x + 10] ^ state[x + 15] ^ state[x + 20] for x in range(5)]
            delta = [columns[(x - 1) % 5] ^ rotate(columns[(x + 1) % 5], 1) for x in range(5)]
            temp = [0] * 25
            for x in range(5):
                for y in range(5):
                    i = x + 5 * y
                    temp[y + 5 * ((2 * x + 3 * y) % 5)] = rotate(state[i] ^ delta[x], rotations[i])
            for x in range(5):
                for y in range(5):
                    state[x + 5 * y] = temp[x + 5 * y] ^ ~temp[(x + 1) % 5 + 5 * y] & temp[(x + 2) % 5 + 5 * y]
            state[0] ^= rc
    return b''.join((v.to_bytes(8, 'little') for v in state))[:32]

def verify_item(raw, item_id, capsule=None):
    require(2 < len(raw) <= 107520, 'Invalid signed data item size')
    kind = int.from_bytes(raw[:2], 'little')
    require(kind in (1, 2, 3), 'Unsupported data item signature type')
    sig_len, owner_len = {1: (512, 512), 2: (64, 32), 3: (65, 65)}[kind]
    signature, owner = (raw[2:2 + sig_len], raw[2 + sig_len:2 + sig_len + owner_len])
    require(encode(hashlib.sha256(signature).digest()) == item_id, 'Signed item ID differs')
    offset = 2 + sig_len + owner_len
    fields = []
    for _ in range(2):
        require(offset < len(raw) and raw[offset] in (0, 1), 'Invalid data item field')
        size = raw[offset] * 32
        offset += 1
        fields.append(raw[offset:offset + size])
        offset += size
    require(offset + 16 <= len(raw), 'Truncated tags header')
    count = int.from_bytes(raw[offset:offset + 8], 'little')
    size = int.from_bytes(raw[offset + 8:offset + 16], 'little')
    offset += 16
    require(count <= 128 and size <= 16384 and (offset + size <= len(raw)), 'Invalid tags length')
    tags, payload = (raw[offset:offset + size], raw[offset + size:])
    message = deep_hash([b'dataitem', b'1', str(kind).encode(), owner, *fields, tags, payload])
    if kind == 1:
        rsa_verify(owner, signature, message)
    elif kind == 2:
        ed25519.Ed25519PublicKey.from_public_bytes(owner).verify(signature, message)
    else:
        key = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256K1(), owner)
        digest = keccak256(b'\x19Ethereum Signed Message:\n' + str(len(message)).encode() + message)
        sig = utils.encode_dss_signature(int.from_bytes(signature[:32], 'big'), int.from_bytes(signature[32:64], 'big'))
        key.verify(sig, digest, ec.ECDSA(utils.Prehashed(hashes.SHA256())))
    decoded = unpack_optional_gzip(payload, MAX_CAPSULE_BYTES)
    require(capsule is None or decoded == capsule, 'Receipt belongs to different capsule bytes')
    return decoded

def public_json(url):
    return json.loads(get_bytes(url, maximum=16 * 1024 * 1024)[0])

def verified_chunk(root, proof, position, total):
    """Verify a data_path and chunk against the signed transaction data_root."""
    h = lambda value: hashlib.sha256(value).digest()
    path, chunk = (decode(proof['data_path']), decode(proof['chunk']))
    require(64 <= len(path) <= 4096 and (len(path) - 64) % 96 == 0, 'Invalid Merkle path')
    require(0 <= position < total, 'Invalid chunk position')
    left, right, node = (0, total, root)
    while len(path) > 64:
        a, b, note, path = (path[:32], path[32:64], path[64:96], path[96:])
        require(h(h(a) + h(b) + h(note)) == node, 'Merkle branch differs')
        split = int.from_bytes(note, 'big')
        require(left < split <= right, 'Invalid Merkle split')
        if position < split:
            node, right = (a, split)
        else:
            node, left = (b, split)
    require(h(h(path[:32]) + h(path[32:])) == node and h(chunk) == path[:32], 'Chunk proof differs')
    require(int.from_bytes(path[32:], 'big') == right and len(chunk) == right - left and (len(chunk) <= 262144), 'Chunk length or range differs')
    return (left, right, chunk)

def settlement(item_id, raw_item=None, *, query=public_json):
    require(re.fullmatch('[A-Za-z0-9_-]{43}', item_id), 'Invalid item ID')
    status = query(f'{TURBO}/v1/tx/{item_id}/status')
    bundle = status.get('bundleId')
    if status.get('status') != 'FINALIZED' or not bundle:
        return ({'status': 'pending', 'provider_status': status.get('status'), 'reason': 'Waiting for Arweave settlement'}, None)
    require(re.fullmatch('[A-Za-z0-9_-]{43}', bundle), 'Invalid bundle ID')
    tx = query(f'{ARWEAVE}/tx/{bundle}')
    require(tx['format'] == 2 and tx['id'] == bundle and (encode(hashlib.sha256(decode(tx['signature'])).digest()) == bundle), 'L1 transaction identity differs')
    message = deep_hash([b'2', decode(tx['owner']), decode(tx['target']), tx['quantity'].encode(), tx['reward'].encode(), decode(tx['last_tx']), [[decode(t['name']), decode(t['value'])] for t in tx['tags']], tx['data_size'].encode(), decode(tx['data_root'])])
    rsa_verify(decode(tx['owner']), decode(tx['signature']), message)
    total = int(tx['data_size'])
    start, size = (status['startOffsetInRootBundle'], status['rawContentLength'])
    require(type(start) is int and type(size) is int and (0 <= start < total) and (0 < size <= 107520) and (start + size <= total) and (status.get('parentDataItemId') is None), 'Unsupported or invalid bundle offset')
    offset = query(f'{ARWEAVE}/tx/{bundle}/offset')
    require(int(offset['size']) == total, 'L1 bundle size differs')
    absolute = int(offset['offset']) - total + 1
    assembled, cursor = (bytearray(), start)
    while cursor < start + size:
        proof = query(f'{ARWEAVE}/chunk/{absolute + cursor}')
        left, right, chunk = verified_chunk(decode(tx['data_root']), proof, cursor, total)
        end = min(right, start + size)
        require(left <= cursor < end, 'Chunk does not cover item')
        assembled.extend(chunk[cursor - left:end - left])
        cursor = end
    found = bytes(assembled)
    verify_item(found, item_id)
    require(raw_item is None or found == raw_item, 'L1 bytes differ from saved item')
    confirmed = query(f'{ARWEAVE}/tx/{bundle}/status')
    block_hash = confirmed['block_indep_hash']
    require(re.fullmatch('[A-Za-z0-9_-]{64}', block_hash), 'Invalid block hash')
    block = query(f'{ARWEAVE}/block/hash/{block_hash}')
    require(block['indep_hash'] == block_hash and block['height'] == confirmed['block_height'] and (bundle in block['txs']) and (confirmed['number_of_confirmations'] > 0), 'Public node confirmation differs')
    return ({'status': 'pass', 'provider_status': status['status'], 'bundle_id': bundle, 'item_in_signed_l1_bundle_verified': True, 'block_height': block['height'], 'block_hash': block_hash, 'block_time_utc': iso(datetime.fromtimestamp(block['timestamp'], timezone.utc)), 'confirmation_source': ARWEAVE, 'consensus_verified_locally': False}, found)

def verify_storage(receipt, item, capsule, before, *, query=public_json, track=True):
    result = {'schema': 'stock-attest/storage-evidence/v1', 'receipt': {'status': 'pending'}, 'content': {'status': 'pending'}, 'settlement': {'status': 'pending'}, 'historical_anonymous_download_verified': False}
    try:
        result['receipt'] = verify_receipt(receipt, receipt['id'], before)
        verify_item(item, receipt['id'], capsule)
        result['content'] = {'status': 'pass', 'capsule_sha256': sha(capsule), 'signed_item_sha256': sha(item)}
    except Exception:
        result['content'] = {'status': 'fail', 'reason': 'Signed receipt or bound file bytes failed verification'}
        return result
    if track:
        try:
            result['settlement'], _ = settlement(receipt['id'], item, query=query)
        except Exception:
            result['settlement'] = {'status': 'pending', 'reason': 'Settlement proof is not verified; retry later'}
    return result
