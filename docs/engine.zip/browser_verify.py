"""Read-only browser entry point for the shared v2 verification rules."""
import base64
import json
from pathlib import Path
from urllib.parse import urlsplit

from attest.calendar import TwseCalendar
from attest.common import AttestError, day, iso, read_json, require, timestamp
from attest.top100 import window_start
from attest.v2.pipeline import validate_capsule
from attest.v2.policy import cid, cutoff
from attest.v2.public_verify import load_public_protocol, registration_claims
from attest.v2.registry import JsonRpc, RegistryReader, choose, compare_snapshots, imported_snapshot
from attest.v2.services import ArchiveReader


class BrowserRpc:
    def __init__(self, url, request):
        self.url = url
        self.request = request
        self.calls = 0

    def call(self, method, params):
        require(method in JsonRpc.READ_METHODS, "RPC method must be read-only")
        self.calls += 1
        body = json.dumps({"jsonrpc": "2.0", "id": self.calls, "method": method, "params": params})
        response = json.loads(self.request(self.url, body))
        require(response.get("id") == self.calls and "error" not in response and "result" in response,
                f"{urlsplit(self.url).hostname} 無法完成 {method} 查詢")
        return response["result"]


def check_capsule(row, protocol, *, is_demo, request, read_archive, progress):
    event = row["candidate"]
    if not event or (not is_demo and not row["third_party_registration_verified"]):
        return {"status": "pending", "reason": "需先確認要比對的正式版本"}
    if not is_demo and read_archive is None:
        return {"status": "pending", "reason": "公開檔案未查詢"}
    expected_cid = event["object_cid"]
    progress("正在比對存證檔的指紋")

    def query_json(url, body):
        try:
            return json.loads(request(url, body.decode("utf-8")))
        except Exception as exc:
            raise AttestError("公開備份索引暫時無法查詢") from exc

    def fetch_bytes(url):
        try:
            return base64.b64decode(read_archive(url), validate=True), {}
        except Exception as exc:
            raise AttestError("公開備份暫時無法讀取") from exc

    try:
        if is_demo:
            raw = Path("demo-capsule.json").read_bytes()
            evidence = {}
        else:
            archive = ArchiveReader(query_json=query_json, fetch_bytes=fetch_bytes)
            raw, evidence = archive.resolve(expected_cid, gateways=("https://arweave.net", "https://turbo-gateway.com"))
    except (AttestError, OSError):
        return {"status": "pending", "reason": "暫時找不到與登記指紋吻合的公開檔案"}
    try:
        require(cid(raw) == expected_cid, "檔案與登記指紋不符")
        capsule = validate_capsule(raw, protocol)
        require(capsule["session_date"] == row["session_date"], "檔案的交易日期不符")
    except (AttestError, ValueError, KeyError, TypeError):
        return {"status": "fail", "reason": "檔案未通過指紋、簽名或交易日期查核"}
    return {"status": "pass", "reason": "檔案指紋及簽名吻合", "object_cid": expected_cid,
            "archive": evidence}


def verify(config, session, request, progress, *, expected_digest=None, read_archive=None):
    is_demo = config["mode"] == "demo"
    protocol = load_public_protocol("protocol.json", expected_digest or config["protocol_sha256"])
    day(session)
    require(day(session) >= day(protocol["start_date"]), "所選日期早於系列起始日")
    if is_demo:
        require(session == config["initial_date"], "請選範例交易日")
        snapshot = imported_snapshot(read_json("registry.fixture.json"))
        start = timestamp(config["demo_window_start_utc"])
        rpc_hosts = []
    else:
        calendar = TwseCalendar(Path("calendar-cache"), fetch=lambda url: json.loads(request(url, "")))
        progress("正在核對交易日與登記窗口")
        require(calendar.is_session(session), "所選日期並非 TWSE 預定交易日")
        start = window_start(protocol, session, calendar)
        sources = config["rpc_sources"]
        rpc_hosts = [urlsplit(source["url"]).hostname for source in sources]
        require(len(rpc_hosts) >= 2 and len(set(rpc_hosts)) == len(rpc_hosts), "需要兩個不同的公開 RPC 來源")
        snapshots = []
        for index, source in enumerate(sources):
            progress(f"正在掃描來源 {index + 1}/{len(sources)} · {rpc_hosts[index]}")
            rpc = BrowserRpc(source["url"], request)
            reader = RegistryReader(rpc, event_topic=config["event_topic"], log_chunk_size=source["log_chunk_size"])
            snapshots.append(reader.scan(protocol, session, start))
        progress("正在比對兩個來源的開盤前紀錄")
        snapshot = compare_snapshots(snapshots, session, protocol=protocol)
    row = choose(snapshot, protocol, session, start)
    row["checks"] = registration_claims(row, protocol)
    row["checks"]["committed_capsule_unchanged"] = check_capsule(
        row, protocol, is_demo=is_demo, request=request, read_archive=read_archive, progress=progress)
    return {"schema": "stock-attest/browser-registration/v1", "fixture_only": is_demo,
            "protocol_sha256": expected_digest or config["protocol_sha256"],
            "registry_location": protocol["registration"], "rpc_hosts": rpc_hosts,
            "window_start_utc": iso(start), "cutoff_utc": iso(cutoff(session, protocol)), "period": row}
