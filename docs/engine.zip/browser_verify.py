"""Read-only browser entry point for the shared v2 verification rules."""
import base64
import json
from pathlib import Path
from urllib.parse import quote, urlsplit

from attest.calendar import TwseCalendar
from attest.common import AttestError, day, iso, read_json, require, sha, timestamp
from attest.top100 import window_start
from attest.v2.pipeline import validate_capsule
from attest.v2.policy import announcement_deadline, cid, cutoff
from attest.v2.publication_evidence import check_public_asset
from attest.v2.public_verify import load_public_protocol, registration_claims
from attest.v2.registry import JsonRpc, RegistryReader, choose, compare_snapshots, imported_snapshot
from attest.v2.services import ArchiveReader


class BrowserRpc:
    def __init__(self, url, request):
        self.url = url
        self.request = request
        self.calls = 0

    def call(self, method, params):
        require(method in JsonRpc.READ_METHODS, "RPC method must be read-only")
        self.calls += 1
        body = json.dumps({"jsonrpc": "2.0", "id": self.calls, "method": method, "params": params})
        response = json.loads(self.request(self.url, body))
        require(response.get("id") == self.calls and "error" not in response and "result" in response,
                f"{urlsplit(self.url).hostname} 無法完成 {method} 查詢")
        return response["result"]


def check_github_asset(protocol, tag, name, raw, before, request):
    repo = protocol['public_evidence']['github_repo']
    url = f'https://github.com/{repo}/releases/tag/{quote(tag, safe="")}'
    api = f'https://api.github.com/repos/{repo}/releases/tags/{quote(tag, safe="")}'
    try:
        release = json.loads(request(api, ''))
        if not isinstance(release, dict) or 'id' not in release:
            return {'status': 'pending', 'reason': 'GitHub 公開紀錄暫時無法確認', 'url': url}
    except Exception:
        return {'status': 'pending', 'reason': 'GitHub 暫時無法查詢，可直接開啟原始頁面', 'url': url}
    try:
        require(release.get('tag_name') == tag, 'Unexpected release tag')
        return {**check_public_asset(release, name, raw, before, repo), 'url': url,
                'reason': 'GitHub 公開時間早於截止，Immutable 附件指紋吻合'}
    except (AttestError, KeyError, TypeError, ValueError):
        return {'status': 'fail', 'reason': 'GitHub 公開時間、不可變狀態或附件指紋未通過查核', 'url': url}


def check_capsule(row, protocol, *, is_demo, request, read_archive, progress):
    event = row["candidate"]
    # Candidate bytes/publication can be checked before the cutoff. The separate
    # complete-history claim remains pending until the official version is final.
    if not event:
        return {"status": "pending", "reason": "需先確認要比對的正式版本"}
    if not is_demo and read_archive is None:
        return {"status": "pending", "reason": "公開檔案未查詢"}
    expected_cid = event["object_cid"]
    progress("正在比對存證檔的指紋")

    def query_json(url, body):
        try:
            return json.loads(request(url, body.decode("utf-8")))
        except Exception as exc:
            raise AttestError("公開備份索引暫時無法查詢") from exc

    def fetch_bytes(url):
        try:
            return base64.b64decode(read_archive(url), validate=True), {}
        except Exception as exc:
            raise AttestError("公開備份暫時無法讀取") from exc

    try:
        if is_demo:
            raw = Path("demo-capsule.json").read_bytes()
            evidence = {}
        else:
            archive = ArchiveReader(query_json=query_json, fetch_bytes=fetch_bytes)
            raw, evidence = archive.resolve(expected_cid, gateways=("https://arweave.net", "https://turbo-gateway.com"))
    except (AttestError, OSError):
        return {"status": "pending", "reason": "暫時找不到與登記指紋吻合的公開檔案"}
    try:
        require(cid(raw) == expected_cid, "檔案與登記指紋不符")
        capsule = validate_capsule(raw, protocol)
        require(capsule["session_date"] == row["session_date"], "檔案的交易日期不符")
    except (AttestError, ValueError, KeyError, TypeError):
        return {"status": "fail", "reason": "檔案未通過指紋、簽名或交易日期查核"}
    publication = ({'status': 'pending', 'reason': '範例不代表真實公開時間'} if is_demo else
                   check_github_asset(protocol,
                       f"commit-{protocol['strategy_id']}-{row['session_date']}-{sha(raw)[:16]}",
                       'capsule.json', raw, cutoff(row['session_date'], protocol), request))
    return {"status": "pass", "reason": "檔案指紋及簽名吻合", "object_cid": expected_cid,
            "archive": evidence, 'github_publication': publication}


def verify(config, session, request, progress, *, expected_digest=None, read_archive=None):
    is_demo = config["mode"] == "demo"
    protocol = load_public_protocol("protocol.json", expected_digest or config["protocol_sha256"])
    day(session)
    require(day(session) >= day(protocol["start_date"]), "所選日期早於系列起始日")
    if is_demo:
        require(session == config["initial_date"], "請選範例交易日")
        snapshot = imported_snapshot(read_json("registry.fixture.json"))
        start = timestamp(config["demo_window_start_utc"])
        rpc_hosts = []
        announcement = {'status': 'pending', 'reason': '範例不代表事前公告'}
    else:
        calendar = TwseCalendar(Path("calendar-cache"), fetch=lambda url: json.loads(request(url, "")))
        progress("正在核對交易日與登記窗口")
        require(calendar.is_session(session), "所選日期並非 TWSE 預定交易日")
        start = window_start(protocol, session, calendar)
        progress('正在核對 GitHub 系列公告')
        announcement = check_github_asset(protocol, 'series-policy-v2', 'protocol.json',
                                         Path('protocol.json').read_bytes(),
                                         announcement_deadline(protocol, calendar), request)
        sources = config["rpc_sources"]
        rpc_hosts = [urlsplit(source["url"]).hostname for source in sources]
        require(len(rpc_hosts) >= 2 and len(set(rpc_hosts)) == len(rpc_hosts), "需要兩個不同的公開 RPC 來源")
        snapshots = []
        for index, source in enumerate(sources):
            progress(f"正在掃描來源 {index + 1}/{len(sources)} · {rpc_hosts[index]}")
            rpc = BrowserRpc(source["url"], request)
            reader = RegistryReader(rpc, event_topic=config["event_topic"], log_chunk_size=source["log_chunk_size"])
            snapshots.append(reader.scan(protocol, session, start))
        progress("正在比對兩個來源的開盤前紀錄")
        snapshot = compare_snapshots(snapshots, session, protocol=protocol)
    row = choose(snapshot, protocol, session, start)
    row["checks"] = registration_claims(row, protocol)
    row["checks"]["committed_capsule_unchanged"] = check_capsule(
        row, protocol, is_demo=is_demo, request=request, read_archive=read_archive, progress=progress)
    return {"schema": "stock-attest/browser-registration/v1", "fixture_only": is_demo,
            "protocol_sha256": expected_digest or config["protocol_sha256"],
            "registry_location": protocol["registration"], "rpc_hosts": rpc_hosts,
            'announcement': announcement,
            "window_start_utc": iso(start), "cutoff_utc": iso(cutoff(session, protocol)), "period": row}
